# RezervoPro Booking Platform

This is the booking platform website for Albania professions.

## How to run

1. Clone the repo
2. Run `npm install`
3. Run `npm run dev` to start the development server.
